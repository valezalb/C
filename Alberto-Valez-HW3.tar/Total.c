#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

int main(int argc, char **argv){
  if(argv[1] != NULL){
    int itter = atoi(argv[1]), total=0;
    for(int i=0; i <= itter ; i++){
      total += i;
    }
    printf("Total[%d] : Sum = %d\n", getpid(), total);
    return total;
  }
  return 0;
}
