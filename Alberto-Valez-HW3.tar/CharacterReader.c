#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/ipc.h>    // shared memory functionality
#include <sys/shm.h>    // shm_open
#include <sys/types.h>  // ftruncate
#include <sys/stat.h>
#include <sys/mman.h>   // mmap

int main(int argc, char **argv){
  if(argc != 3){
    printf("Sorry not enough arguments!\n");
    return -1;
  }
  int sum;
  int fd = atoi(argv[2]);
  char sumOfNum[32],str[100];
  FILE* file = fopen(argv[1],"r");     // Opening the file
  if(file == NULL){                    //Making sure that the file opened
     perror("fopen");
     exit(EXIT_FAILURE);
  }
  while(fgets(str,100,file)){          //Read line and store in str

    if(str[strlen(str)-1]=='\n'){
      str[strlen(str)-1]='\0';         // Replacing newline with null
    }
    char * num;
    const char s[2]="\0";
    num = strtok(str,s);
    sum += atoi(num);
  }
  sprintf(sumOfNum, "%d",sum);     // write the number into the message variable
  write(fd, sumOfNum, strlen(sumOfNum) + 1);
  close(fd);
  return 0;
}
