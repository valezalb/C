#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/ipc.h>    // shared memory functionality
#include <sys/shm.h>    // shm_open
#include <sys/types.h>  // ftruncate
#include <sys/stat.h>
#include <sys/mman.h>   // mmap

int main(int argc, char **argv){

  if(argv[1] != NULL){
    char * file = argv[1];                 //Making sure a file is passed
    int space[2];                        //Creating space for starter and charread
    char buffer[20];

    if (pipe(space) == -1) {                //Making sure our pipe is createed
        fprintf(stderr, "Pipes creation failed.\n");
        return -1;
    }
    //
    pid_t child_pid = fork();            //Our child

    if (child_pid < 0) {                 //Making sure we have a successful fork
        fprintf(stderr, "Fork failed.\n");
        return -1;
    }

    else if (child_pid == 0) {              // child process
        close(space[0]);                    // close the read-end of the pipe
        char writeEnd[16];
        sprintf(writeEnd, "%d",space[1]);
        execlp("./CharacterReader","CharacterReader",file,writeEnd,NULL);
    }
    else {                            // parent process
        close(space[1]);
        wait(NULL);

        int received_count = read(space[0], buffer, sizeof(buffer));
        close(space[0]);
        buffer[received_count] = '\0';
     }
     printf("Starter[%d]: contents read from the read end pipe: %s\n", getppid(), buffer);
    //starting my cocurrent run
    printf("1\n");
    int size = 3, numBytes = 32;
    char fibb[]="Fibb_Mem",prime[]="Prime_Mem",total[]="Total_Mem";
    printf("2\n");
    pid_t *pid=calloc(size,sizeof(pid_t));
    printf("3\n");
    //shared memory for Fibb
    int shm_fibb = shm_open(fibb, O_CREAT | O_RDWR, 0666);
    printf("4\n");
    ftruncate(shm_fibb,numBytes);
    printf("Starter[%d]: Created shared memory \"SHM_Fibb\" with FD: %d\n",getppid(),shm_fibb);
    void *shm_fibbPtr = mmap(0,numBytes, PROT_READ, MAP_SHARED, shm_fibb,0);
    //shared memory for prime
    int shm_prime = shm_open(prime, O_CREAT | O_RDWR, 0666);
    ftruncate(shm_prime,numBytes);
    printf("Starter[%d]: Created shared memory \"SHM_Prime\" with FD: %d\n",getppid(),shm_prime);
    void *shm_primePtr = mmap(0,numBytes, PROT_READ, MAP_SHARED, shm_prime,0);
    //shared memory for Total
    int shm_total = shm_open(total, O_CREAT | O_RDWR, 0666);
    //ftruncate(shm_total,numBytes);
    printf("Starter[%d]: Created shared memory \"SHM_Total\" with FD: %d\n",getppid(),shm_total);
    void *shm_totalPtr = mmap(0,numBytes, PROT_READ, MAP_SHARED, shm_total,0);
    // Making it run concurrent
    for(int i=0; i<size; i++){
      pid[i] = fork();
      if(pid[i]==0){
        if(i==0){
          execlp("./Prime","Prime",buffer,prime,NULL);
        }
        if(i == 1){
          execlp("./Fibb","Fibb",buffer,shm_fibb,fibb,NULL);
        }
        if(i == 2){
          execlp("./Total","Total",buffer,shm_total,total,NULL);
        }
      }
    }
    for(int i=0; i< size; i++){
      waitpid(pid[i],NULL,0);
    }
    printf("Starter[%d]: Fibb last number: %s\n",getppid(),(char *)shm_fibbPtr);
    printf("Starter[%d]: Prime last number: %s\n",getppid(),(char *)shm_primePtr);
    printf("Starter[%d]: Total last number: %s\n",getppid(),(char *)shm_totalPtr);
// print before unlink
    shm_unlink(fibb);   //this might need to be multiple unlinks
    shm_unlink(prime);
    shm_unlink(total);
 }
}
