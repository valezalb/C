#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

int main(int argc, char **argv){

  if(argv[1] != NULL){
     int itter =atoi(argv[1]),counter=0,i,j;
     printf("Prime [%d]: First %d prime numbers are:\n", getpid(),itter);

     for( i=2; i<10000; i++){
       for( j=2; j<=i; j++){
         if(i%j == 0){
           break;
         }
       }
       if(i==j){
         counter++;
         if(counter == itter){
           printf("%d, \n",i);
           return i;
         }
         printf("%d, ",i);
       }
     }
   }

  return 0;
}
