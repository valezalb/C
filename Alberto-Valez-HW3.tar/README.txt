1. Name the function that is used to create a pipe. Which ends denotes the read and the write
ends of a pipe? (2 points)
pipe(space)
2. Name the function used to map files or devices in to memory? (1 point)
mmap(0,numBytes, PROT_READ, MAP_SHARED, shm_prime,0);
3. Name the function used to open a shared memory object? What does it return? (2 points)
shm_open(fibb, O_CREAT | O_RDWR, 0666); it return an integer
