#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

int main(int argc, char **argv){
  if(argv[1] != NULL){
    int itter = atoi(argv[1]),total=0,prev=0,curr=0;
    printf("Fibb[%d] : Number of terms in fibonacii series is %d\n",getpid(),itter);
    printf("Fibb[%d] : The first %d numbers of the Fibonacci sequence are:\n",getpid(),itter);
    for(int i=0;i<itter;i++){
      if(i == 1){
        total = 1;
        printf("%d, ",total);
        continue;
      }
      prev = curr;
      curr = total;
      total = prev + curr;
      printf("%d, ",total);
    }
    printf("\n");
    return total;
  }
  return 0;
}
