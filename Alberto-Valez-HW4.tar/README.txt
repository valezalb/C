1. What is the other name for Shortest Job First Preemptive Algorithm?
SJF
2. What are the 5 different states a process can be in scheduling (Look into process state
diagram)?
wait,ready
3. Shortest Job First is like Priority Scheduling with the priority based on ______ of the process?
shortst bursttime
4. ________ effect is the primary disadvantage of First Come First Serve Scheduling algorithm.
non-premative
5. How does Multi Level Feeedback queue prevent starvation of processes that waits too long in
lower priority queue?
it creates a an aging element which allows for lower priority processesto move up in priority.
