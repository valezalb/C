#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct PCB{
  int pID, arrivalTime, burstTime, priority,turnAround,waitTime;
};

int main(int argc, char **argv){
  int timeQuantum = 0,count=0;char info[11][4][100];
  if (argc >= 3){                      //Makingsure we have all the params
    timeQuantum = atoi(argv[2]);             //assigning the time tq
    FILE* file= fopen(argv[1],"r");
    if(file == NULL){                  //Make sure file opens
      perror("fopen");
      exit(EXIT_FAILURE);
    }
    char str[100];int i = 0;
    while(fgets(str,100,file)){        //iterating through the file
      int j=0;
      if(str[strlen(str)-1]=='\n'){
        str[strlen(str)-1]='\0';         // Replacing newline with null
      }
      char *token = strtok(str,", ");
        while(token != NULL){
          strcpy(info[i][j],token);
          j++;
          token=strtok(NULL,",");
        }
        i++;
    }
    count = i;
    struct PCB processes[count],temp;
    for(int i=1;i<count;i++){
        processes[i].pID = atoi(info[i][0]);
        processes[i].arrivalTime = atoi(info[i][1]);
        processes[i].burstTime = atoi(info[i][2]);
        processes[i].priority = atoi(info[i][3]);
    }
    for(int i=0;i<count-1;i++){                      // placing in oder by id
      for(int j=0;j<count-i-1;j++){
        if(processes[j].pID > processes[j+1].pID){
          temp=processes[j];
          processes[j]=processes[j+1];
          processes[j+1] = temp;
        }
      }
    }
    for(int i=0;i<count-1;i++){                      //Placing in order by arrival
      for(int j=0;j<count-i-1;j++){
        if(processes[j].arrivalTime > processes[j+1].arrivalTime){
          temp=processes[j];
          processes[j]=processes[j+1];
          processes[j+1] = temp;
        }
      }
    }
    //---------START OF THE FCFS PROCESS-----------------------
    float awtFcfs=0,attFcfs=0,tpFcfs=0;
    int start,finish;
    //Getting the turnaround time
    for(int i=1; i<count; i++){
      if(i == 1){
        tpFcfs += processes[i].burstTime;
        start = processes[i].burstTime;
        finish = processes[i].burstTime;
        processes[i].turnAround=finish;
        attFcfs += finish;
        continue;
      }
      if((processes[i].arrivalTime - finish) > 0){
        finish += (processes[i].arrivalTime - finish);
        finish += processes[i].burstTime;
        processes[i].turnAround=finish;
        tpFcfs += finish-start;
        start = finish;
        attFcfs += finish;
        continue;
      }
      finish += processes[i].burstTime;
      tpFcfs = finish-start;
      processes[i].turnAround=finish;
      start = finish;
      attFcfs += finish;
    }
    attFcfs = attFcfs/(count);
    tpFcfs = tpFcfs/count;
    //Getting the waittime
    for(int i=1; i<count; i++){
      processes[i].waitTime=processes[i].turnAround-processes[i].burstTime;
      awtFcfs+=processes[i].waitTime;
    }
    awtFcfs= awtFcfs/(count);
    for(int i=0;i<count-1;i++){                      // placing in oder by id
      for(int j=0;j<count-i-1;j++){
        if(processes[j].pID > processes[j+1].pID){
          temp=processes[j];
          processes[j]=processes[j+1];
          processes[j+1] = temp;
        }
      }
    }
    start = 0;
    finish = 0;
    printf("----------------- FCFS -----------------\n");
    printf("Process ID | Waiting Time | Turnaround Time\n");
    for(int i=1; i<count; i++){
      printf("  %7d  | %10d   |  %5d    \n",processes[i].pID,processes[i].waitTime,processes[i].turnAround);
    }
    printf("\n");
    for(int i=0;i<count-1;i++){                      //Placing in order by arrival
      for(int j=0;j<count-i-1;j++){
        if(processes[j].arrivalTime > processes[j+1].arrivalTime){
          temp=processes[j];
          processes[j]=processes[j+1];
          processes[j+1] = temp;
        }
      }
    }
    printf("Gantt Chart is:\n");
    for(int i=1;i<count;i++){
      if(i == 1){
        start = processes[i].burstTime;
        finish = processes[i].burstTime;
        printf("[  %-2d] --%3d   -- [  %-2d]\n",processes[i].arrivalTime,processes[i].pID,finish);
        continue;
      }
      if((processes[i].arrivalTime - finish) > 0){
        finish += (processes[i].arrivalTime - finish);
        printf("[  %-2d] -- IDLE -- [  %-2d]\n",start,finish);
        start= finish;
        finish += processes[i].burstTime;
        printf("[  %-2d] --%3d   -- [  %-2d]\n",start,processes[i].pID,finish);
        start = finish;
        continue;
      }
      finish += processes[i].burstTime;
      printf("[  %-2d] --%3d   -- [  %-2d]\n",start,processes[i].pID,finish);
      start = finish;
    }
    printf("\n");
    printf("Average Waiting Time: %.2f\n",awtFcfs);
    printf("Average Turnaround Time: %.2f\n",attFcfs);
    printf("Throughput: %.2f\n",tpFcfs);
    printf("\n");
//--------------------START OF PBS------------------------------
    float awtPbs=0,attPbs=0,tpPbs=0;
    for(int i=0;i<count-1;i++){                      //Placing in order by priority
      for(int j=0;j<count-i-1;j++){
        if(processes[j].priority > processes[j+1].priority){
          temp=processes[j];
          processes[j]=processes[j+1];
          processes[j+1] = temp;
        }
      }
    }
    //Getting the turnaround time
    for(int i=1; i<count; i++){
      processes[i].turnAround+=attPbs + processes[i].burstTime;
      attPbs += processes[i].turnAround;
    }
    attPbs = attPbs/count;
    tpPbs=attPbs;
    //Getting the waittime
    for(int i=1; i<count; i++){
      processes[i].waitTime=processes[i].turnAround-processes[i].burstTime;
      awtPbs+=processes[i].waitTime;
    }
    awtPbs= awtPbs/(count);
    for(int i=0;i<count-1;i++){                      // placing in oder by id
      for(int j=0;j<count-i-1;j++){
        if(processes[j].pID > processes[j+1].pID){
          temp=processes[j];
          processes[j]=processes[j+1];
          processes[j+1] = temp;
        }
      }
    }
    start = 0;
    finish = 0;
    printf("----------------- PBS -----------------\n");
    printf("Process ID | Waiting Time | Turnaround Time\n");
    for(int i=1; i<count; i++){
      printf("  %7d  |  %10d  |  %5d    \n",processes[i].pID,processes[i].waitTime,processes[i].turnAround);
    }
    printf("\n");
    printf("Gantt Chart is:\n");
    for(int i=1;i<count;i++){
      if(i == 1){
        start = processes[i].burstTime;
        finish = processes[i].burstTime;
        printf("[  %-2d] --   %-3d--[  %-2d]\n",processes[i].arrivalTime,processes[i].pID,finish);
        continue;
      }
      if((processes[i].arrivalTime - finish) > 0){
        finish += (processes[i].arrivalTime - finish);
        printf("[  %-2d] -- IDLE --[  %-2d]\n",start,finish);
        start= finish;
        finish += processes[i].burstTime;
        printf("[  %-2d] --   %-3d--[  %-2d]\n",start,processes[i].pID,finish);
        start = finish;
        continue;
      }
      finish += processes[i].burstTime;
      printf("[  %-2d] --   %-3d--[  %-2d]\n",start,processes[i].pID,finish);
      start = finish;
    }
    printf("\n");
    printf("Average Waiting Time: %.2f\n",awtPbs);
    printf("Average Turnaround Time: %.2f\n",attPbs);
    printf("Throughput: %.2f\n",tpPbs);
    printf("\n");
    //---------------------START OF RR ------------------------------------------
    int flag=0,time=0,result,prevtime;
    while(!flag){
      for(int i=1;i<count;i++){
        if(processes[i].burstTime == 0){
          continue;
        }
        if(result < 0){
          processes[i-1].turnAround = time - result;
          result = processes[i].burstTime-timeQuantum;

          if(result <= 0){
            if(result == 0){
              processes[i].turnAround=time +result;
            }
            continue;
          }
          result = processes[i].burstTime-timeQuantum;
          time += timeQuantum;
          continue;
        }
        if(time <= processes[i].arrivalTime){
          result = processes[i].burstTime-timeQuantum;
          time += timeQuantum;
          if(result == 0){
            processes[i].turnAround=time +result;
          }
          continue;
        }
      }
      if(time == prevtime){
        flag=1;
      }
      prevtime=time;
    }
    for(int i=1;i<count;i++){
      processes[i].waitTime = processes[i].turnAround - processes[i].arrivalTime;
    }
    printf("----------------- Round Robin -----------------\n");
    printf("Process ID | Waiting Time | Turnaround Time\n");
    for(int i=1; i<count; i++){
      printf("  %7d  |  %10d  |  %5d    \n",processes[i].pID,processes[i].waitTime,processes[i].turnAround);
    }
    printf("\n");
    printf("Gantt Chart is:\n");
    flag=0,time=0,result=0,prevtime=0;
    for(int i=1;i<count;i++){
      if(processes[i].burstTime == 0){
        continue;
      }
      if(result < 0){
        printf("[  %-2d] --   %-3d--[  %-2d]\n",prevtime,processes[i].pID,time);
        time = time-result;
        result = processes[i].burstTime-timeQuantum;
        if(result <= 0){
          if(result == 0){
            printf("[  %-2d] --   %-3d--[  %-2d]\n",prevtime,processes[i].pID,time);
          }
          continue;
        }
        result = processes[i].burstTime-timeQuantum;
        time += timeQuantum;
        continue;
      }
      if(time <= processes[i].arrivalTime){
        result = processes[i].burstTime-timeQuantum;
        time += timeQuantum;
        if(result == 0){
          printf("[  %-2d] --   %-3d--[  %-2d]\n",prevtime,processes[i].pID,time);
        }
        continue;
      }
      printf("[  %-2d] -- IDLE --[  %-2d]\n",prevtime,time);
    }
    if(time == prevtime){
      flag=1;
    }
    prevtime=time;
  }

  return 0;
}
